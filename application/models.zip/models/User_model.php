<?php

	class User_model extends CI_Model{
		public function __construct(){
			$this->load->database();
		}

		public function login($username = '', $password = ''){
			$query = $this->db->get_where('User', array(
				'username' => $username, 
				'password' => $password));
			// get_where('User', array('username' => $username)); = เงื่อนไข 

			if($query->num_rows() === 1) //===typeเดียวกัน
				return true;
			return false;
		}
	}


?>