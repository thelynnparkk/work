<?php

	class User extends CI_Controller{
		public function __construct(){
			parent::__construct();

			$this->load->model('User_model');
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->library('form_validation');
			$this->load->helper('language');
			$this->load->helper('cookie');
		}

		// public function login(){
		// 	$this->form_validation->set_rules('username', 'โปรดกรอกยูสเซอ', required);
		// 	$this->form_validation->set_rules('password', 'โปรดกรอกพาดเวิด', required);

		// 	if($this->form_validation->run() == true){
		// 		$login_result = $this->User_model->login($this->input->post('username'), $this->input->post('password'));
		// 	}
		// 	//$this->User_model->login($this->input)
		// }

		public function login(){
  
			  // $this->data['title'] = $this->lang->line('login_heading');

			  //Check for existing cookie
			  // if($this->User_model->validate_cookie($this->input->cookie('CI_username',true), $this->input->cookie('CI_password')) === true){
			  //  $this->load->view('user/login_success');
			  //  return ;
			  // }

			  //validate form input
			  $this->form_validation->set_rules('username', 'โปรดกรอกยูสเซอ', 'required');
			  $this->form_validation->set_rules('password', 'โปรดกรอกพาดเวิด', 'required');

			  if ($this->form_validation->run() == true){
			   // check to see if the user is logging in
			   // $remember = (bool) $this->input->post('remember');
			   
			   $login_result = $this->User_model->login($this->input->post('username'), $this->input->post('password'));

			   // TODO check for "remember me"

			   if ($login_result == true){
			    //if the login is successful and create cookie
			    // $this->input->set_cookie(array(
			    //  'name' => 'CI_username',
			    //  'value' => $this->input->post('username'),
			    //  'expire' => '10',));
			    // $this->input->set_cookie(array(
			    //  'name' => 'CI_password',
			    //  'value' => $login_result,
			    //  'expire' => '1000',));
			    $this->load->view('user/login_success');
			   }
			   else{
			    // if the login was un-successful
			    // redirect them back to the login page
			    $this->session->set_flashdata('message', "เออเร่ออออออออ");
			       // $this->session->set_flashdata('messageClass','danger');
			    redirect('login', 'refresh'); //ชื่อหน้า, refreshเป็นdefault
			   }
			  }else{
			   // the user is not logging in so display the login page
			   // set the flash data error message if there is one
			   $this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			   // $this->data['messageClass'] = validation_errors() ? 'danger' : $this->session->flashdata('messageClass');

			   $this->data['username'] = array(
			    'name' => 'username',
			    'id'    => 'identity',
			    'type'  => 'text',
			    'required' => 'true',
			    'class' => 'form-control',
			    'placeholder' => 'username',
			    'autofocus' => 'true',
			    'value' => $this->form_validation->set_value('username'),
			   );
			   $this->data['password'] = array(
			    'name' => 'password',
			    'id'   => 'password',
			    'type' => 'password',
			    'required' => 'true',
			    'class' => 'form-control input-lg',
			    'placeholder' => 'password',
			   );

			   $this->load->view('user/login', $this->data);
			  }
			 }






	}


?>