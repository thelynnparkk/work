<div class="panel-body">
  <?php if($message): ?>
  <div>
    <?=$message?>
  </div>
  <?php endif; ?>
 <?=form_open('login')?>
 <div class="form-group">
  <div class="input-group">
   <?=form_input($username)?>
  </div>
 </div>
 <div class="form-group">
  <div class="input-group">
   <?=form_input($password)?>
  </div>
  <div class="checkbox">
   <label>
    <?=form_checkbox('remember', '1', FALSE, 'id="remember"')?> Remember Me
   </label>
  </div>
  <?=form_submit('submit','submit')?>
  <?=form_close()?>
 </div>